import React, { Component } from 'react';
import './App.css';
import { Container, Input, Row, Col, Button, FormText } from 'reactstrap';
import axios from 'axios';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {listData: [

      ],
      tempData: {
        
      },
      addNewItem: false
    };
  }

  componentDidMount = () => {
    //localStorage.setItem('list', JSON.stringify(this.state.listData));
    //console.log(localStorage.getItem('list'));
    if(localStorage.getItem('list') && JSON.parse(localStorage.getItem('list')).length > 0){
      this.setState({listData: JSON.parse(localStorage.getItem('list'))});
    }

    /*var url = "https://sheets.googleapis.com/v4/spreadsheets/1hMUqY3OGEghD55maHFH2fa050vRflKZLgDcmpk1IcV0/?key=AIzaSyDrs_a78fJ038rEE6A4bSeQ8TUZW3dLa1s&includeGridData=true";                                                             
    axios.get(url)
      .then(function (response) {
        console.log(response);                                                                                                                                                    
      })
      .catch(function (error) {
        console.log(error);                                                                                                                                                       
      });*/

  }

  AddToGoogleSheet = () =>{
    var url = "https://sheets.googleapis.com/v4/spreadsheets/1hMUqY3OGEghD55maHFH2fa050vRflKZLgDcmpk1IcV0:batchUpdate";                                                             
    
    var data = {
      "requests": [
       {
        "insertRange": {
         "range": {
          "sheetId": 969828991,
          "startRowIndex": 0,
          "endRowIndex": 1000
         },
         "shiftDimension": "ROWS"
        }
       }
      ]
     };

     this.state.listData.filter((obj, index)=>{
      data.requests.push({
          "pasteData":
            {
            "data": obj.Id +","+obj.WorkItem +","+obj.DueDate +","+obj.NoOfResources,
            "type": "PASTE_NORMAL",
            "delimiter": ",",
            "coordinate": {
              "sheetId": 969828991,
              "rowIndex": index,
            }
            }
        });
        return null;
     });

    const options = {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ya29.GluAB2TqESFR_Mqb5Oz0P4vJIpFwpkW-42TqAuW22epyjck9qJlozNigpm_WayqRQjYewiCIPXaLTVNgEfvHqhVSoaXIvllFeJAASKBIyIp7iiMJQAi7NLjQ5P-Q', 'content-type': 'application/json' },
      data: data,
      url,
    };
    //https://docs.google.com/spreadsheets/d/1hMUqY3OGEghD55maHFH2fa050vRflKZLgDcmpk1IcV0/edit#gid=969828991
    axios(options)
      .then(function (response) {
        alert("Data uploaded successfully");                                                                                                                                                   
      })
      .catch(function (error) {
        console.log(error);                                                                                                                                                       
      });
  }

  handleChange = (e) =>{
    var tempData = this.state.tempData;
    tempData[e.target.name] = e.target.value;
    this.setState({tempData: tempData});
  }

  DeleteItem = (index, item) =>{
    var newList = this.state.listData.filter((obj)=>{
      return obj.Id !== item.Id;
    });
    this.setState({listData: newList, addNewItem: false});
    localStorage.setItem('list', JSON.stringify(newList));
  }

  EditItem = (index, item) =>{
    var tempData, newList = this.state.listData.filter((obj, index)=>{
      if(item.Id === obj.Id){
        obj.IsEdit = true;
        tempData = Object.assign({}, obj);;
      }
      return obj;
    });
    this.setState({listData: newList, tempData: tempData, addNewItem: false});
    //localStorage.setItem('list', JSON.stringify(newList));
  }

  CancelEdit = (index, item) => {
    var tempData = {};
    this.state.listData.filter((obj)=>{
      if(item && item.Id === obj.Id){
        obj.IsEdit = false;
      }
      return obj;
    });
    this.setState({tempData: tempData, addNewItem: false});
    //localStorage.setItem('list', JSON.stringify(newList));
  }

  UpdateItem = (tempData, index) => {
    //Update work item
    var newList = this.state.listData.filter((obj, i)=>{
      if(i === index && !this.state.addNewItem){
        obj.IsEdit = false;
        obj.Id = tempData.Id;
        obj.WorkItem = tempData.WorkItem;
        obj.DueDate = tempData.DueDate;
        obj.NoOfResources = tempData.NoOfResources;
      }
      return obj;
    });
    //Save new work item
    if(index === undefined && tempData){
      newList.unshift(tempData);
    }
    this.setState({listData: newList, addNewItem: false, tempData: {}});
    localStorage.setItem('list', JSON.stringify(newList));
  }

  AddNewItem = () =>{
    if(this.state.tempData.Id){
      var newList = this.state.listData.filter((obj)=>{
        if(this.state.tempData.Id === obj.Id){
          obj.IsEdit = false;
        }
        return obj;
      });
      this.setState({listData: newList, addNewItem: true, tempData: {}});
    }else{
      this.setState({addNewItem: true, tempData: {}});
    }
  }

  render() {
    return (
      <Container>
        <Row>
          <Col sm="6"><span className="border">Zen Assignment</span></Col>
          <Col sm="6" className="text-right"><span className="border">Number of Work Item: {this.state.listData.length}</span></Col>
        </Row>
        <Row>
          <Col sm="6"></Col>
          <Col sm="6" className="text-right">
            <Button color="info" size="sm" onClick={this.AddToGoogleSheet}>Upload to Google Spreadsheet</Button>&nbsp;
            <Button color="info" size="sm" onClick={this.AddNewItem}>Add New Item</Button>
          </Col>
        </Row>
        <Row className="border font-weight-bold">
          <Col className="text-center border-right">ID</Col>
          <Col className="text-center border-right">WorkItem</Col>
          <Col className="text-center border-right">Due Date</Col>
          <Col className="text-center border-right">No. Resources Needed</Col>
          <Col className="text-center">Actions</Col>
        </Row>
        {this.state.listData.length === 0 && !this.state.addNewItem && 
          <Row className="border-left border-right border-bottom">
            <Col className="text-center">No data found...!</Col>
          </Row>
        }
        {this.state.addNewItem &&   
          <Row className="border-left border-right border-bottom">
            <Col className="text-center border-right">
              {<Input name="Id" bsSize="sm" type="text" value={this.state.tempData.Id || ''} onChange={(e)=>{this.handleChange(e)}} />}
            </Col>
            <Col className="text-center border-right">
              {<Input name="WorkItem" bsSize="sm" type="text" value={this.state.tempData.WorkItem || ''} onChange={(e)=>{this.handleChange(e)}} />}
            </Col>
            <Col className="text-center border-right">
              {<Input name="DueDate" bsSize="sm" type="text" value={this.state.tempData.DueDate || ''} onChange={(e)=>{this.handleChange(e)}} />}
            </Col>
            <Col className="text-center border-right">
              {<Input name="NoOfResources" bsSize="sm" type="text" value={this.state.tempData.NoOfResources || ''} onChange={(e)=>{this.handleChange(e)}} />}
            </Col>
            <Col className="text-center">
              {this.state.addNewItem && <Button color="info" size="sm" onClick={()=>{this.UpdateItem(this.state.tempData)}}>Save</Button>}&nbsp;
              {this.state.addNewItem && <Button color="info" size="sm" onClick={()=>{this.CancelEdit()}}>Cancel</Button>}
            </Col>
          </Row>
        }
        {this.state.listData.length > 0 && this.state.listData.map((obj, index)=>{
            return <Row className="border-left border-right border-bottom" key={index}>
              <Col className="text-center border-right">
                {!obj.IsEdit && <FormText>{obj.Id}</FormText>}
                {obj.IsEdit && <Input name="Id" bsSize="sm" type="text" value={this.state.tempData.Id || ''} onChange={(e)=>{this.handleChange(e)}} />}
              </Col>
              <Col className="text-center border-right">
                {!obj.IsEdit && <FormText>{obj.WorkItem}</FormText>}
                {obj.IsEdit && <Input name="WorkItem" bsSize="sm" type="text" value={this.state.tempData.WorkItem || ''} onChange={(e)=>{this.handleChange(e)}} />}
              </Col>
              <Col className="text-center border-right">
                {!obj.IsEdit && <FormText>{obj.DueDate}</FormText>}
                {obj.IsEdit && <Input name="DueDate" bsSize="sm" type="text" value={this.state.tempData.DueDate || ''} onChange={(e)=>{this.handleChange(e)}} />}
              </Col>
              <Col className="text-center border-right">
                {!obj.IsEdit && <FormText>{obj.NoOfResources}</FormText>}
                {obj.IsEdit && <Input name="NoOfResources" bsSize="sm" type="text" value={this.state.tempData.NoOfResources || ''} onChange={(e)=>{this.handleChange(e)}} />}
              </Col>
              <Col className="text-center">
                {obj.IsEdit && <Button color="info" size="sm" onClick={()=>{this.UpdateItem(this.state.tempData, index)}}>Update</Button>}&nbsp;
                {obj.IsEdit && <Button color="info" size="sm" onClick={()=>{this.CancelEdit(index, obj)}}>Cancel</Button>}
                {!obj.IsEdit && <Button color="info" size="sm" onClick={()=>{this.EditItem(index, obj)}}>Edit</Button>}&nbsp;
                <Button color="danger" size="sm" onClick={()=>{this.DeleteItem(index, obj)}}>Delete</Button>
              </Col>
            </Row>
          })
        }
      </Container>
    );
  }
}

export default App;
